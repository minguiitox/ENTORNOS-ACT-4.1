﻿# **BUSCANDO A SCOOBY**
## **Viajando en furgoneta camper**
### **Ahora os contaremos lo que llevamos en nuestra casa con ruedas**
Lo iremos ennumerando de lo que valoramos como lo mas necesario a lo accesorio
pero no por ello menos importante

1. La cama fija siempre bien hecha.
1. Bateria auxliar.
1. Panel solar de 150W, que nunca nos falte energia.
1. Deposito de agua limpia de 30 litros.
1. Deposito de aguas grises de 30 litros.
1. Fregadero que también sirve como lavabo.
1. Nevera de compresor de 12V.
1. WC para hacer lo innombrable.
1. Cocina a gas; para poder hacer ricos y sanos alimentos.
1. Calefacción; por si hace frio no convertirnos en cubitos de hielo.
1. Puertos USB de Carga, para recargar todo lo necesario.
1. Toma de corriente de 12V; por si hace falta enchufar algun accesorio.
1. Inversor de 12V a 220V, por si acaso.
1. Menaje de cocina; no ibamos a cocinar con palos ni comer con las manos.

Y ahora algunos de los lugares en los que hemos estado con nuestra Scoobyneta

- Cañon del Rio Lobo.

Os dejamos una web en la que podeis ve algunas rutas que se pueden realizar allí[](https://www.xn--caondelriolobos-zqb.com/rutas-senderismo.html)

[Rutas Cañon Rio Lobos ](https://www.xn--caondelriolobos-zqb.com/rutas-senderismo.html)

- La Selva de Irati.

algunas fotos de la Selva de Irati 

![](Aspose.Words.da5c61d7-b106-420a-9cd1-a30642a0d89c.001.jpeg) ![](Aspose.Words.da5c61d7-b106-420a-9cd1-a30642a0d89c.002.jpeg)

- Las Landas (Francia).

![](Aspose.Words.da5c61d7-b106-420a-9cd1-a30642a0d89c.003.jpeg) ![](Aspose.Words.da5c61d7-b106-420a-9cd1-a30642a0d89c.004.jpeg)

- Isla de Ré (preciosa y recomendable).
